#!/usr/bin/env perl
# Please refer to the Plain Old Documentation (POD) at the end of this Perl Script for further information

use strict;
use Pod::Usage;
use Smart::Comments;
use Test::WWW::Selenium;
# TODO Remove "no_plan" once number of tests is confirmed
use Test::More "no_plan";

Test::More->builder->output ('/dev/null');



my $VERSION = "0.0.1"; # May be required to upload script to CPAN i.e. http://www.cpan.org/scripts/submitting.html


# http://ctas.paterva.com/view/Specification#Input_.28Maltego_GUI_-.3E__external_program.29
my $maltego_selected_entity_value = $ARGV[0];

# Not used for this Maltego Local Transform
my $maltego_additional_field_values = $ARGV[1];

# "###" is for Smart::Comments CPAN Module
### \$maltego_additional_field_values is: $maltego_additional_field_values;

my @maltego_additional_field_values =
  split( '#', $maltego_additional_field_values );

# Process the command line arguments
chomp($maltego_selected_entity_value);
chomp($maltego_additional_field_values);

# ":D" is deprecated within http://ctas.paterva.com/view/Specification#Messages_to_STDERR_.28progress.2C_debug.29
print STDERR
"Value of \$maltego_selected_entity_value is \"$maltego_selected_entity_value\"\n";

my $facebook_user_id = $maltego_additional_field_values[4];
if ( $facebook_user_id !~ m/uid=/ ) {
    $facebook_user_id = $maltego_additional_field_values[3];
}
$facebook_user_id =~ s/(uid=)//g;

# "###" is for Smart::Comments CPAN Module
### \$facebook_user_id is: $facebook_user_id;

my $selenium = Test::WWW::Selenium->new (host => "localhost",
                                  port => 4444,
                                  browser => "*firefox",
                                  browser_url => "https://www.facebook.com",
);

$selenium->open_ok("https://www.facebook.com/");
$selenium->wait_for_page_to_load_ok(30000);

# REFACTOR with "easydialogs" e.g. http://www.paterva.com/forum//index.php/topic,134.0.html as recommended by Andrew from Paterva
read_config './etc/selenium.conf' => my %config;
my $facebook_email = $config{'Selenium'}{'email'};
my $facebook_password = $config{'Selenium'}{'password'};

$selenium->type_ok("id=email",$facebook_email);
$selenium->type_ok("id=pass",$facebook_password);
$selenium->click_ok("id=loginbutton");
$selenium->wait_for_page_to_load_ok(30000);
# TODO Timeline URL i.e. https://www.facebook.com/$facebook_user_id/friends or photos
# http://facebook.stackoverflow.com/questions/8542871/how-can-i-check-to-see-if-the-user-has-facebook-timeline
# Check for Cover Photo
my $facebook_url_friends = "https://www.facebook.com/profile.php?id=$facebook_user_id?sk=friends";
$selenium->open_ok($facebook_url_friends);
my $friend_list_not_public = 0;
# ->is_text_present_ok had to be modified as the error returned was caught by Maltego
eval { $selenium->is_text_present("Basic Information") };
if ($@ != 0) {
	$friend_list_not_public = 1;
}
	
$selenium->click_ok("id=userNavigationLabel");
$selenium->click_ok("//input[\@value='Log Out']");
$selenium->wait_for_page_to_load_ok(30000);

# http://ctas.paterva.com/view/Specification#Message_Wrapper
print("<MaltegoMessage>\n");
print("<MaltegoTransformResponseMessage>\n");
print ("\t<UIMessages>\n");
print ("\t\t<UIMessage MessageType=\"Inform\">Facebook Public Photo and Friends List Maltego Local Transform v$VERSION</UIMessage>\n");
print ("\t</UIMessages>\n");

# http://ctas.paterva.com/view/Specification#Message_Wrapper
print("\t<Entities>\n");
if ($friend_list_not_public == 0) {
	print("\t\t<Entity Type=\"cmlh.facebook.friends.public\"><Value>Public</Value></Entity>\n");
	print("\t\t<Entity Type=\"maltego.URL\"><Value>Facebook Friends</Value>\n");
	print("\t\t\t<AdditionalFields>\n");
	print("\t\t\t\t<Field Name=\"url\">$facebook_url_friends</Field>\n");
	print("\t\t\t\t<Field Name=\"title\">Friends List</Field>\n");
	print("\t\t\t</AdditionalFields>\n");
	print("\t\t</Entity>\n");
}
# http://ctas.paterva.com/view/Specification#Entity_definition
print("\t</Entities>\n");

# http://ctas.paterva.com/view/Specification#Message_Wrapper
print("</MaltegoTransformResponseMessage>\n");
print("</MaltegoMessage>\n");


=head1 NAME

from_affilation_facebook-to_selenium-facebook_friend_list_is_public.pl - "To Facebook Friend List is Public - Maltego Local Transform"

=head1 VERSION

This documentation refers to from_affilation_facebook-to_selenium-facebook_friend_list_is_public.pl Alpha v$VERSION

=head1 Maltego CONFIGURATION

From Manage->Transform->New Transform
Display Name: "To Facebook Friend List is Public"
For "Description", copy the text from the DESCRIPTION POD section below
Transform ID is "cmlh.facebook.friend.list.public"
Author is "Christian Heinrich"
Input entity type is "Affiliation - Facebook"

=head1 USAGE

from_affilation_facebook-to_selenium-facebook_friend_list_is_public.pl $maltego_selected_entity_value

=head1 REQUIRED ARGUEMENTS

Execute the Selenium-RC as "java -jar selenium-server-standalone-2.20.0.jar > /dev/null 2>&1 &" to redirect standard input and output"
 				
=head1 OPTIONAL ARGUEMENTS

=head1 DESCRIPTION

Returns if the Facebook Friend List is Public 

=head1 DEPENDENCIES

=head1 PREREQUISITES

=head1 COREQUISITES

=head1 OSNAMES

osx

=head1 SCRIPT CATEGORIES

Web

=head1 INCOMPATIBILITIES

=head1 BUGS AND LIMITATIONS

Please refer to the comments beginning with "TODO" in the Perl Code.

=head1 AUTHOR

Christian Heinrich

=head1 CONTACT INFORMATION

http://cmlh.id.au/contact

=head1 MAILING LIST

=head1 REPOSITORY

https://github.com/cmlh/maltego-facebook

=head1 FURTHER INFORMATION AND UPDATES

http://cmlh.id.au/tagged/maltego
http://del.icio.us/cmlh/maltego

=head1 LICENSE AND COPYRIGHT

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License. 

Copyright 2012 Christian Heinrich
